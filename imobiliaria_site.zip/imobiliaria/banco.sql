CREATE DATABASE IF NOT EXISTS imobiliaria;
USE imobiliaria;

CREATE TABLE usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100),
    email VARCHAR(100),
    senha VARCHAR(100)
);

CREATE TABLE corretores (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100),
    creci VARCHAR(20),
    telefone VARCHAR(20)
);

CREATE TABLE imoveis (
    id INT AUTO_INCREMENT PRIMARY KEY,
    titulo VARCHAR(100),
    descricao TEXT,
    valor DECIMAL(10,2),
    cidade VARCHAR(100),
    estado VARCHAR(2),
    imagem VARCHAR(255)
);

CREATE TABLE visitas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    id_usuario INT,
    id_imovel INT,
    data_visita DATE,
    FOREIGN KEY (id_usuario) REFERENCES usuarios(id),
    FOREIGN KEY (id_imovel) REFERENCES imoveis(id)
);
